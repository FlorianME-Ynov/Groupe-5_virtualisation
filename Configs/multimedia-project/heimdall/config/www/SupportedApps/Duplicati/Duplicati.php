<?php namespace App\SupportedApps\Duplicati;

class Duplicati extends \App\SupportedApps {

}