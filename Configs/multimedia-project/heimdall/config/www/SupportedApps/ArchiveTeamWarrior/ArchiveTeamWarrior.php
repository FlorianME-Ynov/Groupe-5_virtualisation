<?php namespace App\SupportedApps\ArchiveTeamWarrior;

class ArchiveTeamWarrior extends \App\SupportedApps {

}