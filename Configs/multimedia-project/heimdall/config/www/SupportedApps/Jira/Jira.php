<?php namespace App\SupportedApps\Jira;

class Jira extends \App\SupportedApps {

}