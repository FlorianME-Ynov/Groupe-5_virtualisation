<?php namespace App\SupportedApps\Booksonic;

class Booksonic extends \App\SupportedApps {

}