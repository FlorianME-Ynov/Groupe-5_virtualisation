<ul class="livestats">
    <li>
        <span class="title">Progress</span>
        <strong>{!! $progress !!}<span>%</span></strong>
    </li>
    <li class="right">
        <span class="title">Finish</span>
        <strong>{!! $estimated !!}</strong>
    </li>
</ul>