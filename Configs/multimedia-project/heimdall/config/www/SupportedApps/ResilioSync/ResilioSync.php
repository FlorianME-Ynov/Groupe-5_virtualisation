<?php namespace App\SupportedApps\ResilioSync;

class ResilioSync extends \App\SupportedApps {

}