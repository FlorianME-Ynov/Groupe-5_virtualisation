<ul class="livestats">
    <li>
        <span class="title">Missing</span>
        <strong>{!! $movies !!} Movies</strong>
    </li>
    <li>
        <span class="title">&nbsp;</span>
        <strong>{!! $series !!} TV</strong>
    </li>
</ul>
