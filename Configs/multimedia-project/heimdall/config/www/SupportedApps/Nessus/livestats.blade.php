<ul class="livestats">
    <li>
        <span class="title">Active scan</span>
        <span><strong>{!! $scanner !!}</strong></span>
    </li>
</ul>